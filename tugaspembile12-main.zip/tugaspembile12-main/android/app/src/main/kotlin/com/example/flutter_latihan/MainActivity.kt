package com.example.flutter_latihan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
